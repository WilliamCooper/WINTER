### plot 14: UHSAS
RPlot14 <- function (data) {}
### add footer if reimplemented
# if (testPlot (14)) {
# op <- par (mfrow=c(1,1), mar=c(4,5,2,2)+0.1)
# plot (Time, data$CONCU_RWO, ylab="CONCU", type='l', log='y')
# points (Time, data$CONCU100_RWO, type='l', col="green")
# points (Time, data$CONCU500_RWO, type='l', col="red")
# }

